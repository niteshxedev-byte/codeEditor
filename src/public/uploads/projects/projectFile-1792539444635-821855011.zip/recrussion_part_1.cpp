#include <bits/stdc++.h>
using namespace std;

int  factorial(int n ){
    if(n==0){
        return 1; 

    }
    int ans = n* factorial(n-1);
    return ans;


}

int power(int n){
    if(n==0){
        return 1;
    }
    return 2*power(n-1);
}

// void printCountingRev(int n){
//     if(n==0){
//         return ;
//     }
//     cout<<n<<",";
//     return printCountingRev(n-1);
// }

void printCounting(int n){
    if(n==0){
        return ;
    }
    
  printCounting(n-1);
    cout<<n<<",";
}


void reachHome(int src,int desination){
    cout<<"source =>"<< src<<"desination =>"<<desination<<endl;
    if(src == desination ){
        cout<<"finally reached"<<endl;
        return;
    }
    src++;
reachHome(src,desination);
}



int fibbonacciNumber(int n){
    if(n==0){
        return 0 ; 
    }
     if(n==1){
        return 1 ; 
    }
   return  fibbonacciNumber(n-1) +fibbonacciNumber(n-2);

} 
int main(){
    int n = 6;
  cout<<  factorial(n)<<endl;
  cout<< power(n)<<endl;
//    printCountingRev(n);
printCounting(n);


// reach home 
int src= 1;
int desination = 10;

reachHome(src,desination);


// fibbonacciNumber 

// 0,1,1,2,3,5,8
cout<< fibbonacciNumber(n);



   return 0;
}