// Recursion examples in C++

#include <iostream>

// Factorial
unsigned long long factorial(unsigned int n) {
    if (n == 0) return 1;
    return n * factorial(n - 1);
}

// Fibonacci (simple recursive, not efficient)
unsigned int fibonacci(unsigned int n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

// Sum of array using recursion
int sumArray(const int arr[], int size) {
    if (size == 0) return 0;
    return arr[0] + sumArray(arr + 1, size - 1);
}

// Count down
void countDown(int n) {
    if (n <= 0) return;
    std::cout << n << " ";
    countDown(n - 1);
}

// Tower of Hanoi (demonstration)
void towerOfHanoi(int n, char from, char to, char via) {
    if (n == 1) {
        std::cout << "Move disk 1 from " << from << " to " << to << std::endl;
        return;
    }
    towerOfHanoi(n - 1, from, via, to);
    std::cout << "Move disk " << n << " from " << from << " to " << to << std::endl;
    towerOfHanoi(n - 1, via, to, from);
}

int main() {
    // Factorial example
    std::cout << "Factorial of 5: " << factorial(5) << std::endl;

    // Fibonacci example
    std::cout << "Fibonacci of 6: " << fibonacci(6) << std::endl;

    // Sum of array example
    int data[] = {1, 2, 3, 4, 5};
    std::cout << "Sum of array: " << sumArray(data, 5) << std::endl;

    // Count down example
    std::cout << "Count down: ";
    countDown(5);
    std::cout << std::endl;

    // Tower of Hanoi example (3 disks)
    std::cout << "Tower of Hanoi steps:" << std::endl;
    towerOfHanoi(3, 'A', 'C', 'B');

    return 0;
}