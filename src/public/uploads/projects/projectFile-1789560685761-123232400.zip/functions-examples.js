// ============================================
// JAVASCRIPT FUNCTIONS - COMPREHENSIVE EXAMPLES
// ============================================

// --------------------------------------------
// 1. FUNCTION DECLARATIONS (Hoisted)
// --------------------------------------------
function greet(name) {
  return `Hello, ${name}!`;
}

function add(a, b) {
  return a + b;
}

console.log("1. Function Declarations:");
console.log(greet("Alice"));  // Hello, Alice!
console.log(add(5, 3));       // 8


// --------------------------------------------
// 2. FUNCTION EXPRESSIONS (Not hoisted)
// --------------------------------------------
const multiply = function(a, b) {
  return a * b;
};

const divide = function(a, b) {
  if (b === 0) throw new Error("Cannot divide by zero");
  return a / b;
};

console.log("\n2. Function Expressions:");
console.log(multiply(4, 5));  // 20
console.log(divide(10, 2));   // 5


// --------------------------------------------
// 3. ARROW FUNCTIONS (ES6+)
// --------------------------------------------
const subtract = (a, b) => a - b;
const power = (base, exp) => Math.pow(base, exp);
const isEven = num => num % 2 === 0;
const square = x => x * x;

// Arrow function with block body
const factorial = (n) => {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
};

console.log("\n3. Arrow Functions:");
console.log(subtract(10, 4));   // 6
console.log(power(2, 3));       // 8
console.log(isEven(7));         // false
console.log(square(5));         // 25
console.log(factorial(5));      // 120


// --------------------------------------------
// 4. DEFAULT PARAMETERS
// --------------------------------------------
function greetWithDefault(name = "Guest", greeting = "Hello") {
  return `${greeting}, ${name}!`;
}

function createUser(name, role = "user", permissions = []) {
  return { name, role, permissions };
}

console.log("\n4. Default Parameters:");
console.log(greetWithDefault());                    // Hello, Guest!
console.log(greetWithDefault("Bob"));               // Hello, Bob!
console.log(greetWithDefault("Carol", "Hi"));       // Hi, Carol!
console.log(createUser("Dave"));                    // { name: 'Dave', role: 'user', permissions: [] }
console.log(createUser("Eve", "admin", ["read", "write"]));


// --------------------------------------------
// 5. REST PARAMETERS & SPREAD
// --------------------------------------------
function sum(...numbers) {
  return numbers.reduce((acc, n) => acc + n, 0);
}

function logArgs(first, second, ...rest) {
  console.log("First:", first);
  console.log("Second:", second);
  console.log("Rest:", rest);
}

const nums = [1, 2, 3];
console.log("\n5. Rest Parameters & Spread:");
console.log(sum(1, 2, 3, 4, 5));        // 15
console.log(sum(...nums));              // 6 (spread)
logArgs("a", "b", "c", "d", "e");


// --------------------------------------------
// 6. HIGHER-ORDER FUNCTIONS
// --------------------------------------------
// Functions that take functions as arguments or return functions

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// map, filter, reduce - built-in higher-order functions
const doubled = numbers.map(n => n * 2);
const evens = numbers.filter(n => n % 2 === 0);
const total = numbers.reduce((acc, n) => acc + n, 0);

console.log("\n6. Higher-Order Functions (Built-in):");
console.log("Doubled:", doubled);
console.log("Evens:", evens);
console.log("Total:", total);

// Custom higher-order function
function createMultiplier(factor) {
  return function(number) {
    return number * factor;
  };
}

const double = createMultiplier(2);
const triple = createMultiplier(3);

console.log("Double 5:", double(5));   // 10
console.log("Triple 5:", triple(5));   // 15


// --------------------------------------------
// 7. CALLBACK FUNCTIONS
// --------------------------------------------
function fetchData(callback) {
  setTimeout(() => {
    const data = { id: 1, name: "Sample Data" };
    callback(null, data);
  }, 100);
}

function processData(err, data) {
  if (err) {
    console.error("Error:", err);
    return;
  }
  console.log("Processed:", data);
}

console.log("\n7. Callback Functions:");
fetchData(processData);
// Note: This is async, so "Processed" will appear after this log


// --------------------------------------------
// 8. CLOSURES
// --------------------------------------------
function createCounter() {
  let count = 0;  // Private variable
  
  return {
    increment: () => ++count,
    decrement: () => --count,
    getCount: () => count,
    reset: () => { count = 0; }
  };
}

const counter1 = createCounter();
const counter2 = createCounter();

console.log("\n8. Closures:");
console.log(counter1.increment());  // 1
console.log(counter1.increment());  // 2
console.log(counter1.getCount());   // 2
console.log(counter2.increment());  // 1 (separate closure)
counter1.reset();
console.log(counter1.getCount());   // 0


// --------------------------------------------
// 9. IIFE (Immediately Invoked Function Expression)
// --------------------------------------------
const result = (function() {
  const privateVar = "I'm private!";
  return {
    getPrivate: () => privateVar,
    publicMethod: () => "Public method called"
  };
})();

console.log("\n9. IIFE:");
console.log(result.getPrivate());    // I'm private!
console.log(result.publicMethod());  // Public method called


// --------------------------------------------
// 10. GENERATOR FUNCTIONS
// --------------------------------------------
function* numberGenerator() {
  yield 1;
  yield 2;
  yield 3;
}

function* fibonacci() {
  let [a, b] = [0, 1];
  while (true) {
    yield a;
    [a, b] = [b, a + b];
  }
}

console.log("\n10. Generator Functions:");
const gen = numberGenerator();
console.log(gen.next().value);  // 1
console.log(gen.next().value);  // 2
console.log(gen.next().value);  // 3

const fib = fibonacci();
console.log("First 5 Fibonacci:", 
  Array.from({ length: 5 }, () => fib.next().value)
);  // [0, 1, 1, 2, 3]


// --------------------------------------------
// 11. ASYNC FUNCTIONS
// --------------------------------------------
async function fetchUserData(userId) {
  // Simulating API call
  await new Promise(resolve => setTimeout(resolve, 100));
  return { id: userId, name: `User ${userId}`, email: `user${userId}@example.com` };
}

async function getMultipleUsers(ids) {
  const promises = ids.map(id => fetchUserData(id));
  return Promise.all(promises);
}

console.log("\n11. Async Functions:");
fetchUserData(42).then(user => console.log("User:", user));

getMultipleUsers([1, 2, 3]).then(users => {
  console.log("Multiple users:", users);
});


// --------------------------------------------
// 12. FUNCTION COMPOSITION
// --------------------------------------------
const pipe = (...fns) => x => fns.reduce((v, f) => f(v), x);
const compose = (...fns) => x => fns.reduceRight((v, f) => f(v), x);

const add1 = x => x + 1;
const double2 = x => x * 2;
const square2 = x => x * x;

const add1ThenDouble = pipe(add1, double2);
const doubleThenSquare = compose(square2, double2);

console.log("\n12. Function Composition:");
console.log("add1ThenDouble(5):", add1ThenDouble(5));    // (5+1)*2 = 12
console.log("doubleThenSquare(3):", doubleThenSquare(3)); // (3*2)^2 = 36


// --------------------------------------------
// 13. CURRYING
// --------------------------------------------
function curry(fn) {
  return function curried(...args) {
    if (args.length >= fn.length) {
      return fn.apply(this, args);
    }
    return (...moreArgs) => curried(...args, ...moreArgs);
  };
}

const addThree = (a, b, c) => a + b + c;
const curriedAdd = curry(addThree);

console.log("\n13. Currying:");
console.log(curriedAdd(1)(2)(3));      // 6
console.log(curriedAdd(1, 2)(3));      // 6
console.log(curriedAdd(1)(2, 3));      // 6


// --------------------------------------------
// 14. MEMOIZATION
// --------------------------------------------
function memoize(fn) {
  const cache = new Map();
  return function(...args) {
    const key = JSON.stringify(args);
    if (cache.has(key)) {
      console.log(`Cache hit for ${key}`);
      return cache.get(key);
    }
    const result = fn.apply(this, args);
    cache.set(key, result);
    return result;
  };
}

const slowFibonacci = n => {
  if (n <= 1) return n;
  return slowFibonacci(n - 1) + slowFibonacci(n - 2);
};

const fastFibonacci = memoize(slowFibonacci);

console.log("\n14. Memoization:");
console.time("First call");
console.log("fib(10):", fastFibonacci(10));
console.timeEnd("First call");

console.time("Second call (cached)");
console.log("fib(10):", fastFibonacci(10));
console.timeEnd("Second call (cached)");


// --------------------------------------------
// 15. THIS CONTEXT & BIND/CALL/APPLY
// --------------------------------------------
const person = {
  name: "John",
  greet: function(greeting, punctuation) {
    return `${greeting}, ${this.name}${punctuation}`;
  }
};

const anotherPerson = { name: "Jane" };

console.log("\n15. This Context:");
console.log(person.greet("Hello", "!"));                    // Hello, John!
console.log(person.greet.call(anotherPerson, "Hi", "?"));   // Hi, Jane?
console.log(person.greet.apply(anotherPerson, ["Hey", "."])); // Hey, Jane.

const boundGreet = person.greet.bind(anotherPerson);
console.log(boundGreet("Greetings", "!"));                  // Greetings, Jane!


// --------------------------------------------
// 16. PRACTICAL PATTERNS
// --------------------------------------------

// Module Pattern
const Calculator = (function() {
  let result = 0;
  
  return {
    add: function(n) { result += n; return this; },
    subtract: function(n) { result -= n; return this; },
    multiply: function(n) { result *= n; return this; },
    divide: function(n) { result /= n; return this; },
    getResult: function() { return result; },
    clear: function() { result = 0; return this; }
  };
})();

console.log("\n16. Practical Patterns - Module:");
console.log(Calculator.add(10).multiply(2).subtract(5).getResult()); // 15

// Factory Function
function createLogger(prefix) {
  return {
    log: (msg) => console.log(`[${prefix}] ${msg}`),
    error: (msg) => console.error(`[${prefix}] ERROR: ${msg}`),
    warn: (msg) => console.warn(`[${prefix}] WARN: ${msg}`)
  };
}

const appLogger = createLogger("APP");
const dbLogger = createLogger("DB");

console.log("\n16. Practical Patterns - Factory:");
appLogger.log("Application started");
dbLogger.error("Connection failed");


// --------------------------------------------
// RUN ALL EXAMPLES
// --------------------------------------------
console.log("\n✅ All function examples executed!");