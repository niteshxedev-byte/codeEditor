// Welcome to Personal Code Editor
// Select a programming language above and write code or ask AI agents.

function greet(name) {
    console.log(`Hello, ${name}!`);
}

greet("Developer");