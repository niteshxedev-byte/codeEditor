#include <iostream>

int main() {
    // Print text to the console
    std::cout << "Hello, World!" << std::endl;
    
    return 0;
}
