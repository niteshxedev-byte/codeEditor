/**
 * Bubble Sort implementation in JavaScript
 * Sorts an array in-place and returns the sorted array.
 */
function bubbleSort(arr) {
    const n = arr.length;
    // Perform n-1 passes
    for (let i = 0; i < n - 1; i++) {
        // Last i elements are already sorted
        for (let j = 0; j < n - i - 1; j++) {
            // Swap if current element is greater than next
            if (arr[j] > arr[j + 1]) {
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
            }
        }
    }
    return arr;
}

// Example usage:
const unsorted = [64, 34, 25, 12, 22, 11, 90];
console.log('Unsorted:', unsorted);
const sorted = bubbleSort(unsorted.slice()); // use slice to keep original unchanged
console.log('Sorted:', sorted);