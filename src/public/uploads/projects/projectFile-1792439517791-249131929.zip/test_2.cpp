#include <bits/stdc++.h>
using namespace std;

// Left rotate the vector by one position
void leftRotateByOne(vector<int> &nums) {
    int n = nums.size();
    if (n <= 1) return; // nothing to rotate
    int first = nums[0];
    for (int i = 0; i < n - 1; ++i) {
        nums[i] = nums[i + 1];
    }
    nums[n-1] = first;
}

// Print the contents of the vector
void prnt(const vector<int> &nums) {
    for (int x : nums) {
        cout << x << " ";
    }
    cout << '\n';
}

int main() {
    // Example input array
    vector<int> nums = {1, 2, 3, 4, 5};
    leftRotateByOne(nums);
    prnt(nums);
    return 0;
}
