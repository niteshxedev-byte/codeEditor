#include <bits/stdc++.h>
using namespace std;

/*
Dry run of the program with the example input:
nums = {1, 1, 0, 0, 1, 1, 1, 0}

Iteration 0: nums[0] = 1
    cs = 1, ans = 1
Iteration 1: nums[1] = 1
    cs = 2, ans = 2
Iteration 2: nums[2] = 0
    cs = 0, ans = 2
Iteration 3: nums[3] = 0
    cs = 0, ans = 2
Iteration 4: nums[4] = 1
    cs = 1, ans = 2
Iteration 5: nums[5] = 1
    cs = 2, ans = 2
Iteration 6: nums[6] = 1
    cs = 3, ans = 3
Iteration 7: nums[7] = 0
    cs = 0, ans = 3

Final answer: 3
*/

// Class containing the solution for finding the maximum number of consecutive 1s in a binary array
class Solution {
public:
    // Function that takes a reference to a vector of integers and returns the maximum length of consecutive 1s
    int findMaxConsecutiveOnes(vector<int>& nums) {
        int ans = 0;          // Stores the maximum length found so far
        int cs = 0;           // Current streak of consecutive 1s
        int n = nums.size();  // Length of the input array
        for (int i = 0; i < n; ++i) {          // Iterate over each element
            if (nums[i] == 1) {                // If the current element is 1
                cs = cs + 1;                   // Increment the current streak
                ans = max(ans, cs);            // Update the maximum if current streak is larger
            } else {                           // If the current element is 0
                cs = 0;                        // Reset the current streak
            }
        }
        return ans; // Return the maximum consecutive ones found
    }
};

int main() {
    // Example input array
    vector<int> nums = {1, 1, 0, 0, 1, 1, 1, 0};
    Solution sol; // Create an instance of the Solution class
    int result = sol.findMaxConsecutiveOnes(nums); // Call the function
    cout << "Maximum consecutive ones: " << result << endl; // Output the result
    return 0; // Exit the program
}
